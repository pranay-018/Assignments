package com.DEC5.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "couTable")
public class Course {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int courseID;
	private String courseName;
	private Double courseCost;

	/**
	 * @param courseID
	 * @param courseName
	 * @param courseCost
	 */
	public Course(int courseID, String courseName, Double courseCost) {
		this.courseID = courseID;
		this.courseName = courseName;
		this.courseCost = courseCost;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Double getCourseCost() {
		return courseCost;
	}

	public void setCourseCost(Double courseCost) {
		this.courseCost = courseCost;
	}

	@Override
	public String toString() {
		return "Course [courseID=" + courseID + ", courseName=" + courseName + ", courseCost=" + courseCost + "]";
	}

	public Course() {

	}

}
