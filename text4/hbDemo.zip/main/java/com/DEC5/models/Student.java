package com.DEC5.models;

import javax.annotation.processing.Generated;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "stuTable")
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int studentId;
	private String studentName;
	@OneToOne
	@JoinColumn(name="cid",referencedColumnName = "courseID",unique = true)
	private Course course;
	private String mobileNumber;

	private String email;

	public Student() {
	}

	/**
	 * @param studentId
	 * @param studentName
	 * @param course
	 * @param mobileNumber
	 * @param email
	 */
	public Student(int studentId, String studentName, Course course, String mobileNumber, String email) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.course = course;
		this.mobileNumber = mobileNumber;
		this.email = email;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", course=" + course
				+ ", mobileNumber=" + mobileNumber + ", email=" + email + "]";
	}

}
