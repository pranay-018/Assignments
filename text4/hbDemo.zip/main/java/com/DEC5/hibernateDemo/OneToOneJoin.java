package com.DEC5.hibernateDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.DEC5.models.Course;
import com.DEC5.models.Student;

public class OneToOneJoin {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory(); // read the configuratin in session factory
																				// of hibernate.cfg.xml

		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();

		Course c = new Course(1, "c++", 10000.0); // need to double only not in here in constructor won't excplicity
													// convert int to double
		session.save(c);
		System.out.println("course is added");
		Student student = new Student(101, "prani", c, "993258741", "prani@gmail.com");
		session.save(student);

		System.out.println("student inserted");
		// deleting student
//		Student s = session.get(Student.class, 1);
//		if (s != null) {
//			session.delete(s);
//		}
//		System.out.println("deleted ");
		tx.commit();
		session.close();
		sessionFactory.close();

	}

}
