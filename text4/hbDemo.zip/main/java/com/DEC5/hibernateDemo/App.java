package com.DEC5.hibernateDemo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.DEC5.models.Course;
import com.DEC5.models.Student;

/**
 * Hello Hibernate!
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello Hibernate!");

		Configuration cfg = new Configuration().configure();
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		// insertion
//		Student s = new Student(150, "padma", "telugu", "753968412", "padma@gmail.com");
//		session.save(s);
//		// retrival
//
//		Student s2 = session.get(Student.class, 1);
//		System.out.println(s2);
//		List<Student> students = session.createQuery("From Student", Student.class).list();
//		for (Student s : students) {
//			System.out.println(s);
//		}
//		Student s2 = session.get(Student.class, 1);
//		System.out.println(s2);
//		if(s2!=null) {
//			s2.setStudentName("pranay reddy");
//			s2.setEmail("pranayreddy@gmail.com");
//		}
//		session.update(s2);
//		if(s2!=null) session.delete(s2);
//		
//		Course c = new Course(101,"maths",450.36);
//		session.save(c);
		tx.commit();
		session.close();
		sessionFactory.close();
	}
}
