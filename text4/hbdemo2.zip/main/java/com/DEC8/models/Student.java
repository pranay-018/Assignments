package com.DEC8.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name = "stud_table")

// for using named Query
@NamedQueries({ @NamedQuery(name = "Student.findAll", query = "From Student"),
		@NamedQuery(name = "Student.findByCourse", query = "From Student where course=:c"),
		@NamedQuery(name = "Student.count", query = "select count(*) From Student"),
		@NamedQuery(name = "Student.groupByCourse", query = "select course , count(*) From Student group by course"), })
public class Student {
	@Id
	private int sid;
	private String sname;
	private String course;

	/**
	 * @param sid
	 * @param sname
	 * @param course
	 */
	public Student(int sid, String sname, String course) {
		this.sid = sid;
		this.sname = sname; 
		this.course = course;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	@Override
	public String toString() {
		return "Student [sid=" + sid + ", sname=" + sname + ", course=" + course + "]";
	}

}
