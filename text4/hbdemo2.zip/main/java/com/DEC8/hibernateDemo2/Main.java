package com.DEC8.hibernateDemo2;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.DEC8.models.Student;
import com.DEC8.util.HibernateUtil;

public class Main {

	public Main() { 
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
 
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();

//		Student s = new Student(105, "latha", "java");
//		Student s2 = new Student(106, "padma", "telugu");
//		Student s3 = new Student(107, "abhi", "marketing");
//		Student s4 = new Student(109, "ramesh", "c++");
//		session.save(s);
//		session.save(s2);
//		session.save(s3);
//		session.save(s4);

//		List<Student> stuList = session.createQuery("From Student", Student.class).list();
//		stuList.forEach(System.out::println);

		// GET STUDENTS BY COURSE

//		Query<Student> q1 = session.createQuery("From Student where course=:c");
//		q1.setParameter("c", "maths");
//		q1.list().forEach(System.out::println);

		// getAll STudents starts with P
//		Query<Student> q2 = session.createQuery("From Student where sname like 'p%'");
//		q2.list().forEach(System.out::println);

		// projection (need only particular columns)
//		Query<Student> q2 = session.createQuery("From Student where sname like 'p%'");
//		q2.list().forEach(System.out::println);
//		List<Student> rows = q2.list();
//		q2.list().forEach(s->System.out.println(s.getSid()+"  "+s.getSname()));

//		Query<Student> q3 = session.createQuery("select count(*) From Student");
//		System.out.println(q3.uniqueResult());

//		Query<Object[]> q4 = session.createQuery("select course , count(*) From Student group by course",Object[].class);
//		 List<Object[]> groupList = q4.list();
//		 groupList.forEach(s->{
//			 System.out.println("course : "+(String)s[0]+"  count : "+(Long)s[1]);
//		 });
		// named Query
//		Query<Student> q5 = session.createNamedQuery("Student.findByCourse", Student.class);
//		q5.setParameter("c", "c++");
//		q5.list().forEach(System.out::print);
//
//		Query<Long> q7 = session.createNamedQuery("Student.count", Long.class);
//		System.out.println(q7.getSingleResult());

		Query<Object[]> q8 = session.createNamedQuery("Student.groupByCourse", Object[].class);
		q8.list().forEach(s -> System.out.println(" course : " +  s[0] + "  count : " + s[1]));

		tx.commit(); 
		session.close();

	}

}
