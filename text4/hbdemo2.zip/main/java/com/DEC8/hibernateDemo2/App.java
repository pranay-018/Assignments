package com.DEC8.hibernateDemo2;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.DEC8.models.Student;
import com.DEC8.util.HibernateUtil;

/**
 * Hello world!
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello Hibernate!");

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
//        
//        Student s = new Student(103,"prani","social"); // transient --> can't create or save column , table in database
//        session.save(s); // persistance state
//        System.out.println("succesfully inserted");

		// retrives
		List<Student> studList = session.createQuery("From Student", Student.class).list(); // HQL query Language
		for (Student st : studList) {
			System.out.println(st);
		}
		tx.commit();
		session.close(); // detatch

	}
}
