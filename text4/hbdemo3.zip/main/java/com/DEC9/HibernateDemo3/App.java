package com.DEC9.HibernateDemo3;

import java.util.logging.LogManager;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.DEC9.models.NonVeg;
import com.DEC9.models.Product;
import com.DEC9.models.Vehicle;
import com.DEC9.util.HibernateUtil;

/**
 * Hello world!
 */
public class App {
	private static final Logger logger = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) {
		// single type inheritence
//		System.out.println("Hello World!");
//		Session session = HibernateUtil.getSessionFactory().openSession();
//		logger.info("session created");
//		Transaction tx = session.beginTransaction();
//		logger.info("transaction started");
//		Product p = new Product(138, "Bottle");
//		session.save(p);
//		logger.info("saved Data");
//		tx.commit();
//		logger.info("tranaction commited");
//		session.close();
//		logger.info("session closed");
		// Joined Type  // best for lazy loading
//		System.out.println("Hello World!");
//		Session session = HibernateUtil.getSessionFactory().openSession();
//		logger.info("session created");
//		Transaction tx = session.beginTransaction();
//		logger.info("transaction started");
//		Vehicle v = new Vehicle("TS 21 A 5336 ", "Bottle");
//		session.save(v);
//		logger.info("saved Data");
//		tx.commit();
//		logger.info("tranaction commited");
//		session.close();
//		logger.info("session closed");
		// table for class

		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		Transaction tx = session.beginTransaction();
		logger.info("transaction started");
		NonVeg nv = new NonVeg("chicken");
		session.save(nv);
		logger.info("saved Data");
		tx.commit();
		logger.info("tranaction commited");
		session.close();

	}
}
