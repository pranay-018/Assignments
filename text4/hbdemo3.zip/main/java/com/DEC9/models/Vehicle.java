package com.DEC9.models;

import org.hibernate.query.sqm.IntervalType;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.Table;

@Entity
@Table(name = "vec_table")
@Inheritance(strategy = InheritanceType.JOINED)
public class Vehicle {
	@Id
	private String id;
	private String type;

	public Vehicle() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param type
	 */
	public Vehicle(String id, String type) {
		this.id = id;
		this.type = type;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Vehicle [id=" + id + ", type=" + type + "]";
	}

}
