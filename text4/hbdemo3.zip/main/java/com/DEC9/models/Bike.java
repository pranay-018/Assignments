package com.DEC9.models;

import jakarta.persistence.Entity;

@Entity
public class Bike extends Vehicle{
	private String bikeBrand;
	private Double cost;

	/**
	 * @param bikeBrand
	 * @param cost
	 */
	public Bike(String bikeBrand, Double cost) {
		this.bikeBrand = bikeBrand;
		this.cost = cost;
	}

	public Bike() {
		// TODO Auto-generated constructor stub
	}

	public String getBikeBrand() {
		return bikeBrand;
	}

	public void setBikeBrand(String bikeBrand) {
		this.bikeBrand = bikeBrand;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Bike [bikeBrand=" + bikeBrand + ", cost=" + cost + "]";
	}

}
