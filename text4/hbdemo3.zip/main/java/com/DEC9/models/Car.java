package com.DEC9.models;

import jakarta.persistence.Entity;

@Entity
public class Car extends Vehicle {
	private String brand;
	private String color;

	public Car() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param brand
	 * @param color
	 */
	public Car(String brand, String color) {
		this.brand = brand;
		this.color = color;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Car [brand=" + brand + ", color=" + color + "]";
	}
	

}
