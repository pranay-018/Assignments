package com.DEC9.models;

import jakarta.persistence.Entity;

@Entity
public class Veg extends Food {
	private int rating;
	private double cost;

	public Veg() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param rating
	 * @param cost
	 */
	public Veg(int rating, double cost) {
		this.rating = rating;
		this.cost = cost;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Veg [rating=" + rating + ", cost=" + cost + "]";
	}

}
