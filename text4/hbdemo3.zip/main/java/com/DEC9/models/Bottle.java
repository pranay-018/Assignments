package com.DEC9.models;

import jakarta.persistence.Entity;

@Entity
public class Bottle extends Product {
	private String brand;
	private double bottleCost;
	private double capacity;

	public Bottle() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param brand
	 * @param bottleCost
	 * @param capacity
	 */
	public Bottle(String brand, double bottleCost, double capacity) {
		this.brand = brand;
		this.bottleCost = bottleCost;
		this.capacity = capacity;
	}

	public double getBottleCost() {
		return bottleCost;
	}

	public void setBottleCost(double bottleCost) {
		this.bottleCost = bottleCost;
	}

	@Override
	public String toString() {
		return "Bottle [brand=" + brand + ", bottleCost=" + bottleCost + ", capacity=" + capacity + "]";
	}

}
