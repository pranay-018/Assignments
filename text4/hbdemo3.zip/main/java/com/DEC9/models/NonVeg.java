package com.DEC9.models;

import jakarta.persistence.Entity;

@Entity
public class NonVeg extends Food {
	private String animal;

	public NonVeg() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param animal
	 */
	public NonVeg(String animal) {
		this.animal = animal;
	}

	public String getAnimal() {
		return animal;
	}

	public void setAnimal(String animal) {
		this.animal = animal;
	}

	@Override
	public String toString() {
		return "NonVeg [animal=" + animal + "]";
	}

}
