
package com.DEC9.util;

import java.io.IOException;
import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.DEC9.models.Product;

public class HibernateUtil {

	private static SessionFactory sessionFactory = buildSessionFactory();

	public HibernateUtil() {
		// TODO Auto-generated constructor stub
	}

	public static SessionFactory buildSessionFactory() {
		Properties props = new Properties();
		try {
			props.load(HibernateUtil.class.getClassLoader().getResourceAsStream("application.properties"));
		} catch (IOException e) {

			e.printStackTrace();
		}
		Configuration configuration = new Configuration();
		configuration.addAnnotatedClass(com.DEC9.models.Product.class);
		configuration.addAnnotatedClass(com.DEC9.models.Laptop.class);
		configuration.addAnnotatedClass(com.DEC9.models.Bottle.class);
		configuration.addAnnotatedClass(com.DEC9.models.Bike.class);
		configuration.addAnnotatedClass(com.DEC9.models.Car.class);
		configuration.addAnnotatedClass(com.DEC9.models.Food.class);
		configuration.addAnnotatedClass(com.DEC9.models.NonVeg.class);
		configuration.addAnnotatedClass(com.DEC9.models.Veg.class);
		configuration.setProperties(props);
		StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
				.applySettings(configuration.getProperties());
		return configuration.buildSessionFactory(builder.build());

	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

}
