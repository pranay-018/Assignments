package com.DEC9.models;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "dept_table")
public class Department {

	@Id
	private int deptId;
	private String dname;

	@OneToMany(mappedBy = "dept", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private List<Employee> empList;

	public Department() {
		// TODO Auto-generated constructor stub
	}
	public Department(String dname) {
		this.dname = dname;
	}
	public void addEmployee(Employee e) {
		empList.add(e);
		e.setDept(this);
	}
	public void removeEmployee(Employee e) {
		empList.remove(e);
		
	}

}
