package com.DEC9.models;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "person_table")
public class Person {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Size(min = 3, message = "Person must be min of char")
	@NotNull // not null

	private String name;

	@Pattern(regexp = "", message = "enter valid number , starts with 6,7,8,9 and length as 10 digits")
	private String mobile;
	@Email
	private String email;
	@OneToOne(mappedBy = "person", cascade = CascadeType.ALL)
	private PassPort passport;

	public Person() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param id
	 * @param name
	 * @param mobile
	 * @param email
	 * @param password
	 */
	public Person(Long id, @Size(min = 3, message = "Person must be min of char") @NotNull String name,
			@Pattern(regexp = "", message = "enter valid number , starts with 6,7,8,9 and length as 10 digits") String mobile,
			@Email String email, PassPort password) {
		this.id = id;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.passport = password;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public PassPort getPassport() {
		return passport;
	}

	public void setpassPort(PassPort passport) {
		this.passport = passport;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", mobile=" + mobile + ", email=" + email + ", password="
				+ passport + "]";
	}

}
