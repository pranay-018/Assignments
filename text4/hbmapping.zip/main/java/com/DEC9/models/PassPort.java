package com.DEC9.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Size;

@Entity
public class PassPort {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Size(min = 8, message = "must be 8 chars")
	private String passportNumber;
	@OneToOne
	@JoinColumn(name = "person_id",referencedColumnName = "id")
	private Person person;

	/**
	 * @param id
	 * @param passportNumber
	 * @param person
	 */
	public PassPort(Long id, @Size(min = 8, message = "must be 8 chars") String passportNumber, Person person) {
		this.id = id;
		this.passportNumber = passportNumber;
		this.person = person;
	}

	/**
	 * @param id
	 * @param passportNumber
	 */
	public PassPort(Long id, @Size(min = 8, message = "must be 8 chars") String passportNumber) {
		this.id = id;
		this.passportNumber = passportNumber;
	}

	public PassPort() {
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	@Override
	public String toString() {
		return "PassPort [id=" + id + ", passportNumber=" + passportNumber + ", person=" + person + "]";
	}

}
