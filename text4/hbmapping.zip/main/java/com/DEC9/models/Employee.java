package com.DEC9.models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "emp_table")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empId;
	private String ename;
	@ManyToOne
	@JoinColumn(name = "deptId",referencedColumnName = "deptId")
	private Department dept;
	public Employee() {
		// TODO Auto-generated constructor stub
	}

}
