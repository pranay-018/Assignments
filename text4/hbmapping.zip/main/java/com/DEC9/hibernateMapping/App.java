package com.DEC9.hibernateMapping;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.DEC9.DAOs.PersonDAOImpl;
import com.DEC9.models.PassPort;
import com.DEC9.models.Person;

/**
 * Hello world!
 */
public class App {
	private static final Logger logger = LoggerFactory.getLogger(App.class);

	public static void main(String[] args) {
//		System.out.println("Hello World!");
//		logger.info("app started");
//		PassPort pass1 = new PassPort(1l, "india12");
//		logger.info("passpoer generated : {} ", pass1);
//		Person p = new Person(1l, "pranay", "9874563215", "pranay@gmail.com", pass1);
//		logger.info("person genertaed {} ", p);
////		new PersonDAOImpl().addPerson(p);
//
////		new PersonDAOImpl().findAll().forEach(System.out::println);
//		System.out.println(new PersonDAOImpl().finById(1));
//		logger.info("app closed");

	}
}
