package com.DEC9.DAOs;

public class EmployeeDAO {

	public EmployeeDAO() {
		// TODO Auto-generated constructor stub
	}

}
