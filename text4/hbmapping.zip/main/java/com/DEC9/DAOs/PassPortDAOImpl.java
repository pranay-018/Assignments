package com.DEC9.DAOs;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.DEC9.models.PassPort;
import com.DEC9.models.Person;
import com.DEC9.util.HibernateUtil;

public class PassPortDAOImpl implements PassPortDAOInterface {
	private static final Logger logger = LoggerFactory.getLogger(PassPortDAOInterface.class);

	@Override
	public List<PassPort> findAll() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		List<PassPort> plist = session.createQuery("From PassPort", PassPort.class).list();
		logger.info("retirved passports");
		session.close();
		logger.info("session close");
		return plist;
	}

	@Override
	public void addPassport(PassPort passport) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		Transaction tx = session.beginTransaction();
		logger.info("session created");
		session.save(passport);
		logger.info("saved into db successfully ");
		tx.commit();
		logger.info("tx commited");
		session.close();
		logger.info("session closed");

	}

	@Override
	public PassPort findById(long id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		PassPort p = session.get(PassPort.class, id);
		session.close();
		logger.info("session closed");
		logger.info("Passport details with id {} , {}", id, p);
		return p;
	}

	@Override
	public Person findByPersonIdWithPassportDetails(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public PassPort findByPersonId(Long pid) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Query<PassPort> q = session.createQuery("From PassPort where PassPort.person_id=:pid", PassPort.class);
		PassPort p = q.setParameter("id", pid).getSingleResult();
		session.close();
		return p;

	}

}
