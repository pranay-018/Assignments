package com.DEC9.DAOs;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.DEC9.models.Person;
import com.DEC9.util.HibernateUtil;

public class PersonDAOImpl implements PersonDAOInterface {
	private static final Logger logger = LoggerFactory.getLogger(PersonDAOImpl.class);

	public PersonDAOImpl() {

	}

	@Override
	public List<Person> findAll() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		List<Person> plist = session.createQuery("From Person", Person.class).list();
		logger.info("retirved persons");
		session.close();
		logger.info("session close");
		return plist;
	}

	@Override
	public void addPerson(Person p) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		Transaction tx = session.beginTransaction();
		logger.info("session created");
		session.save(p.getPassport());
		session.save(p);
		logger.info("saved into db successfully ");
		tx.commit();
		logger.info("tx commited");
		session.close();
		logger.info("session closed");

	}

	@Override
	public Person finById(long id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		logger.info("session created");
		Person p = session.get(Person.class, id);
		session.close();
		logger.info("session closed");
		logger.info("person details with id {} , {}", id, p);
		return p;
	}

	@Override
	public Person findByPersonIdWIthPassport(long id) {
		return null;
	}

}
