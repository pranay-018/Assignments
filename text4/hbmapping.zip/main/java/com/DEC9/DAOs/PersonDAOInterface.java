package com.DEC9.DAOs;

import java.util.List;

import com.DEC9.models.Person;

public interface PersonDAOInterface {
	public List<Person> findAll();

	public void addPerson(Person p);

	public Person finById(long id);

	public Person findByPersonIdWIthPassport(long id);

}
