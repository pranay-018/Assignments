package com.DEC9.DAOs;

import java.util.List;

import com.DEC9.models.PassPort;
import com.DEC9.models.Person;

public interface PassPortDAOInterface {
	public List<PassPort> findAll();

	public void addPassport(PassPort passport);

	public PassPort findById(long id);

	public Person findByPersonIdWithPassportDetails(long id);

}
