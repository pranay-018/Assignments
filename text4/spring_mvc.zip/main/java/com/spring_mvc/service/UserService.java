package com.spring_mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring_mvc.daos.UserDao;
import com.spring_mvc.model.User;

@Service
public class UserService {
	@Autowired
	UserDao dao;

	public boolean doAuthenticate(String role, String uname, String pwd) {
		List<User> list = dao.findAll();
		for (User u : list) {
			if (u.getUserName().equals(uname) && u.getPassword().equals(pwd) && u.getRole().equals(role)) {
				return true;
			}

		}
		return false;
	}

	public User getDetails(Long uid) {
		List<User> list = dao.findAll();
		for (User u : list) {
			if (u.getId() == uid)
				return u;
		}
		return null;
	}

	@Transactional(readOnly = false)
	public User addUser(User user) {

		dao.save(user);
		return user;
	}

	public User getById(long id) {
		return dao.findById(id);
	}

	public List<User> getAllDetails() {
		return dao.findAll();
	}

	public User updateDetails(User u) {
		return dao.updateById(u);
	}

	public User deleteDetails(Long id) {
		return dao.DeleteById(id);
	}
}
