package com.spring_mvc.service;

import java.util.ArrayList;

import org.springframework.stereotype.Service;

import com.spring_mvc.model.User;

@Service
public class AuthService {

	private static ArrayList<User> list = new ArrayList<User>();

	static {
//		list.add(new User("pranay", "pranay123", "user", "pranay@email.com", "9589693214"));
//		list.add(new User("raju", "raju123", "admin", "raju@email.com", "8589693214"));
//		list.add(new User("padma", "padma", "user", "padma@email.com", "9989693214"));
//		list.add(new User("prani", "prani123", "manager", "prani@email.com", "8989693214"));
	}

	public boolean doAuthenticate(String role, String uname, String pwd) {
		for (User u : list) {
			if (u.getUserName().equals(uname) && u.getPassword().equals(pwd) && u.getRole().equals(role)) {
				return true;
			}

		}
		return false;
	}

	public User getDetails(String uname) {
		for (User u : list) {
			if (u.getUserName().equals(uname))
				return u;
		}
		return null;
	}

	public User addUser(User user) {
		list.add(user);
		getUserList();
		return user;
	}

	private void getUserList() {
		for(User u:list) {
			System.out.println(u);
		}
		
	}

}
