package com.spring_mvc.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan("com.spring_mvc")
@EnableWebMvc
public class WebConfig {

	@Bean
	public InternalResourceViewResolver getResolver() {
		InternalResourceViewResolver r = new InternalResourceViewResolver();

		r.setPrefix("/WEB-INF/views/");
		r.setSuffix(".jsp");
		return r;
	}
}
