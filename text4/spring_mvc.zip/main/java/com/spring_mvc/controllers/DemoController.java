package com.spring_mvc.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring_mvc.model.User;
import com.spring_mvc.service.AuthService;

@Controller
public class DemoController {

	@Autowired
	AuthService authService;

	public DemoController() {

	}

	@RequestMapping("/login")
	public ModelAndView login() {
		return new ModelAndView("login");
	}

	@RequestMapping("/home/{role}")
	public ModelAndView home(@PathVariable("role") String role, @RequestParam("uname") String uname,
			@RequestParam("pwd") String pwd) {

		if (authService.doAuthenticate(role, uname, pwd)) {
			ModelAndView view = new ModelAndView("home");
			view.addObject("username", uname);
			return view;

		}
		return new ModelAndView("error");

	}

	@RequestMapping("/userInfo/{uname}")
	public ModelAndView userDetails(@PathVariable("uname") String uname) {
		User u = authService.getDetails(uname);
		ModelAndView view = new ModelAndView("info");
		view.addObject("user", u);
		return view;
	}

	@RequestMapping("/signup")
	public ModelAndView signUp() {
		ModelAndView mv = new ModelAndView("addUser");
		return mv;

	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public ModelAndView addUser(@ModelAttribute User u) {
		ModelAndView mv = new ModelAndView("result");
		User user = authService.addUser(u);
		mv.addObject("username", user.getUserName());
		return mv;

	}

}
