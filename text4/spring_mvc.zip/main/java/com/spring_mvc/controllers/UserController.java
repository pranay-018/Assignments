	package com.spring_mvc.controllers;
	
	import java.util.List;
	
	import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;
	
	import com.spring_mvc.model.User;
	import com.spring_mvc.service.UserService;
	
	@RestController
	public class UserController {
		@Autowired
		UserService service;
	
		@GetMapping("/user/{id}")
		public User getUserDetails(@PathVariable Long id) {
			return service.getById(id);
		}
	
		@PostMapping("/user")
		public User save(@RequestBody User user) {
			return service.addUser(user);
		}
	
		@GetMapping("/user")
		public List<User> getUserList() {
			return service.getAllDetails();
		}
		
		@PutMapping("/user")
		public User updateDetails(@RequestBody User user) {
			return service.updateDetails(user);
		}
		
		@DeleteMapping("/user/{id}")
		public User deleteDetails(@PathVariable Long id) {
			return service.deleteDetails(id);
		}
	
	}
