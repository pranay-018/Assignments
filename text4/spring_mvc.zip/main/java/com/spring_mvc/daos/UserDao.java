package com.spring_mvc.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.spring_mvc.model.User;

@Repository
public class UserDao {
	@Autowired
	private HibernateTemplate template;

	public List<User> findAll() {
		return template.loadAll(User.class);
	}

	public User save(User u) {
		template.save(u);
		return u;
	}

	public User findById(Long id) {
		return template.get(User.class, id);
	}

	public User updateById(User user) {
		User u = findById(user.getId());
		if (u != null) {
			u.setUserName(user.getUserName());
			u.setEmail(user.getEmail());
			u.setMobileNumber(user.getMobileNumber());
			u.setRole(user.getRole());
		}
		template.update(u);
		return u;
	}

	public User DeleteById(Long id) {
		User u = findById(id);
		template.delete(u);
		return u;
	}

}
