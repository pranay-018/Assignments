<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<form action="addUser" method="post">
		userName : <input type="text" name="userName"><br>
		password : <input type="password" name="password"><br>
		role : <input type="text" name="role"><br> email : <input
			type="text" name="email"><br> phn no: <input type="text"
			name="mobileNumber"><br> <input type="submit"
			value="add user">
	</form>
</body>
</html>