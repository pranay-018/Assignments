<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1>${user.userName}</h1>
	<h1>${user.role}</h1>
	<h1>${user.mobileNumber}</h1>
	<h1>${user.email}</h1>

</body>
</html>