<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<form method="post" id="loginform" onsubmit="return login()">
		<select id="role" name="role">
			<option value="admin">Admin</option>
			<option value="user">User</option>
			<option value="manager">manager</option>
		</select> <label>UserName : </label> <input type="text" name="uname" id="uname">
		<br> <label>Password : </label> <input type="password" name="pwd"
			id="pwd"> <br> <input type="submit" value="login">
	</form>
	<script type="text/javascript">
		function login() {
			let f = document.getElementById("loginform");
			let role = document.getElementById("role").value;
			f.action = "home/" + role
			return true;

		}
	</script>
</body>
</html>