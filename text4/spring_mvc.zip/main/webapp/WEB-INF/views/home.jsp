<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1>Welcome</h1>
	<h1>Hello ${username}</h1>
	<form onsubmit="return info()" id="userform">
		<input type="submit" value="UserInfo">
	</form>
	<script type="text/javascript">
		function info() {
			let f = document.getElementById("userform");
			let name = "${username}";
			f.action = "${pageContext.request.contextPath}/userInfo/" + name;
			return true;

		}
	</script>

	
</body>
</html>