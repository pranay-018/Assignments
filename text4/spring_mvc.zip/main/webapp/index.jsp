<html>
<body>
	<h2><%="Demo Login using Spring Web MVC"%></h2>
	<form action="login">
		<input type="submit" value="login">
	</form>
	<form action="signup">
		<input type="submit" value="signup">
	</form>
</body>
</html>
