package com.springBoot.Entities;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "item_table")
public class Item {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long itemId;
	@NotBlank(message = "Item name is mandatory")
	@Size(min = 2, max = 50, message = "Item must be 2-50 charactres")
	private String itemName;
	@NotNull(message = "Item cost is mandatory")
	@Min(value = 1, message = "Item cost must be greater than 0")
	private Double itemCost;

	@ManyToMany(mappedBy = "itemList")
	@JsonBackReference
	private List<Order> orders;

	public Item() {
	}

	public Item(String name, Double cost) {
		super();
		this.itemName = name;
		this.itemCost = cost;
	}

	public Long getItemId() {
		return itemId;
	}

	public void setItemId(Long itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Double getItemCost() {
		return itemCost;
	}

	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}

	@Override
	public String toString() {
		return "Item [ItemId=" + itemId + ", itemName=" + itemName + ", itemCost=" + itemCost + "]";
	}

}
