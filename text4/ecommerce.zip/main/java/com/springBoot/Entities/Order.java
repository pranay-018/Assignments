package com.springBoot.Entities;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name ="orders")
public class Order {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long orderId;
	@NotNull(message = "order date can't be null")
	private LocalDate ordDate;
	@NotBlank(message = "customer name is mandatory")
	@Size(min = 3, message = "name must be atleast 3 chars")
	private String custName;
	@ManyToMany
	@JoinTable(name = "order_item", joinColumns = @JoinColumn(name = "orderId"), inverseJoinColumns = @JoinColumn(name = "itemId"))
	@JsonManagedReference
	private List<Item> itemList;

	public Order() {
		super();
	}

	public Order(Long orderId, @NotNull(message = "order date can't be null") LocalDate ordDate,
			@NotBlank(message = "customer name is mandatory") @Size(min = 3, message = "name must be atleast 3 chars") String custName,
			List<Item> itemList) {
		super();
		this.orderId = orderId;
		this.ordDate = ordDate;
		this.custName = custName;
		this.itemList = itemList;
	}

	public Order(@NotNull(message = "order date can't be null") LocalDate ordDate,
			@NotBlank(message = "customer name is mandatory") @Size(min = 3, message = "name must be atleast 3 chars") String custName,
			List<Item> itemList) {
		super();
		this.ordDate = ordDate;
		this.custName = custName;
		this.itemList = itemList;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOrdDate() {
		return ordDate;
	}

	public void setOrdDate(LocalDate ordDate) {
		this.ordDate = ordDate;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public List<Item> getItemList() {
		return itemList;
	}

	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}

	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", ordDate=" + ordDate + ", custName=" + custName + ", itemList="
				+ itemList + "]";
	}

}
