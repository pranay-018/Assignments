package com.springBoot.daos;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springBoot.Entities.Item;
import com.springBoot.repositories.ItemRepository;

@Repository
public class ItemDao implements ItemDaoInterface {
	@Autowired
	ItemRepository itemRespository;

	public List<Item> findAll() {
		return itemRespository.findAll();
	} 

	public Optional<Item> findById(Long id) {
		return itemRespository.findById(id);
	}

	public Item save(Item item) {
		return itemRespository.save(item);
	}

	@Override
	public Item update(Item item) {
		itemRespository.save(item);
		return item;
	}

	@Override
	public void delete(Long id) {

		itemRespository.deleteById(id);
	}

	@Override
	public List<Item> findItemsByIds(List<Long> Ids) {
		return itemRespository.findAllById(Ids);

	}

}
