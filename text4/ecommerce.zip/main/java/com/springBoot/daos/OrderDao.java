package com.springBoot.daos;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springBoot.Entities.Order;
import com.springBoot.repositories.OrderRepository;

@Repository
public class OrderDao implements OrderDaoInterface {

	@Autowired
	OrderRepository orderRepository;

	@Override
	public List<Order> findAll() {
		return orderRepository.findAll();
	}

	@Override
	public Optional<Order> findById(Long orderId) {
		return orderRepository.findById(orderId);
	}

	@Override
	public Order save(Order order) {
		orderRepository.save(order);
		return order;
	}

}
