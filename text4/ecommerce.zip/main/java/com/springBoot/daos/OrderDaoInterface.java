package com.springBoot.daos;

import java.util.List;
import java.util.Optional;

import com.springBoot.Entities.Order;

public interface OrderDaoInterface {
	public List<Order> findAll();
	public Optional<Order> findById(Long orderId);
	public Order save(Order order);
	
}
