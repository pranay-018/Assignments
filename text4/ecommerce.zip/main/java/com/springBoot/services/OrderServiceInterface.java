package com.springBoot.services;

import java.util.List;

import com.springBoot.Entities.Order;

public interface OrderServiceInterface {
	public List<Order> findAll();

	public Order findById(Long orderId);

	public Order save(Order order,List<Long> itemIds);
}
