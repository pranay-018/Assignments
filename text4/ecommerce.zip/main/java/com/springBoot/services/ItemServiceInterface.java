package com.springBoot.services;

import java.util.List;

import com.springBoot.Entities.Item;
import com.springBoot.dtos.ItemDTO;

public interface ItemServiceInterface {
	public List<Item> findAll();

	public Item findById(Long id);

	public Item save(ItemDTO itemDto);

	public Item update(Item item, Long id);

	public void delete(Long id);
}
