package com.springBoot.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springBoot.Entities.Order;
import com.springBoot.daos.ItemDao;
import com.springBoot.daos.OrderDao;
import com.springBoot.exceptions.OrderNotFoundException;

@Service
public class OrderService implements OrderServiceInterface {

	@Autowired
	OrderDao orderDao;
	@Autowired
	ItemDao itemDao;

	@Override
	public List<Order> findAll() {
		return orderDao.findAll();
	}

	@Override
	public Order findById(Long orderId) {
		return orderDao.findById(orderId).orElseThrow(() -> new OrderNotFoundException("Not found"));
	}

	@Override
	@Transactional
	public Order save(Order order, List<Long> itemIds) {
		order.setItemList(itemDao.findItemsByIds(itemIds));
		orderDao.save(order);
		return order;
	}

}
