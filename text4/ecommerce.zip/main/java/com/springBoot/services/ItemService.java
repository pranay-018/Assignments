package com.springBoot.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springBoot.Entities.Item;
import com.springBoot.daos.ItemDao;
import com.springBoot.dtos.ItemDTO;
import com.springBoot.exceptions.ItemNotFoundException;

@Service
public class ItemService implements ItemServiceInterface {
	@Autowired
	ItemDao itemDao;

	@Override
	public List<Item> findAll() {
		return itemDao.findAll();
	}

	@Override
	@Transactional
	public Item findById(Long id) {

		return itemDao.findById(id).orElseThrow(() -> new ItemNotFoundException("Not found"));
	}

	@Override
	@Transactional
	public Item save(ItemDTO itemDto) {
		Item item = new Item();
		item.setItemName(itemDto.getItemName());
		item.setItemCost(itemDto.getItemCost());
		return itemDao.save(item);
	}

	@Override
	@Transactional
	public Item update(Item item, Long id) {
		Item i = itemDao.findById(id).orElseThrow(() -> new ItemNotFoundException("Not found"));

		if (i != null) {
			i.setItemCost(item.getItemCost());
			i.setItemName(item.getItemName());
			itemDao.update(i);
			return i;
		}
		return null;
	}

	@Override
	@Transactional
	public void delete(Long id) {
		Item i = itemDao.findById(id).orElseThrow(() -> new ItemNotFoundException("Not found"));
		if (i != null) {
			itemDao.delete(i.getItemId());
			System.out.println("deleted successfully");
		}
		System.out.println("not found");
	}

}
