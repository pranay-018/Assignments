package com.springBoot.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspect.class);

	@Pointcut("execution(* com.springBoot.controllers.*.*(..))")
	public void controllerLayer() {
	}

	@Pointcut("execution(* com.springBoot.services.*.*(..))")
	public void serviceLayer() {
	}

	@Pointcut("execution(* com.springBoot.daos.*.*(..))")
	public void daoLayer() {
	}

	@Before("controllerLayer() || serviceLayer() || daoLayer()")
	public void beforeEachMethod(JoinPoint jp) {
		LOGGER.info("START->{}", jp.getSignature());
	}

	@AfterReturning(pointcut = "execution(* com.springBoot.controllers.*.*(..))", returning = "result")
	public void afterReturningFromEachMethod(JoinPoint jp, Object result) {
		LOGGER.info("SUCCESS->{}", jp.getSignature().getName());
		LOGGER.info("RESULT->{}", result);
	}

	@AfterThrowing(pointcut = "execution(* com.springBoot.controllers.*.*(..))", throwing = "ex")
	public void afterException(JoinPoint jp, Exception ex) {
		LOGGER.error("ERROR->{}", jp.getSignature() + " Exception->{}", ex.getMessage());
	}

	@After("execution(* com.springBoot.controllers.*.*(..))")
	public void logAfter(JoinPoint jp) {
		LOGGER.info("END->{}", jp.getSignature().getName());
	}
}
