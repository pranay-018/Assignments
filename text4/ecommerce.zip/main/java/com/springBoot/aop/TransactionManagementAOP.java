package com.springBoot.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class TransactionManagementAOP {
	@Around("@annotation(org.springframework.transaction.annotation.Transactional)")
	public Object transactionAdvice(ProceedingJoinPoint pjp) throws Throwable {
		
		Object result = null;
		try {
			 result = pjp.proceed();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
