package com.springBoot.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springBoot.Entities.Order;
import com.springBoot.dtos.OrderDTO;
import com.springBoot.services.OrderService;

import io.micrometer.core.ipc.http.HttpSender.Response;

@RestController
@RequestMapping("/order")
public class OrderController {
	@Autowired
	OrderService orderService;

	@GetMapping("/")
	public ResponseEntity<List<Order>> findAll() {
		return new ResponseEntity<List<Order>>(orderService.findAll(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Order> findById(@PathVariable Long id) {
		return new ResponseEntity<Order>(orderService.findById(id), HttpStatus.OK);
	}

	@PostMapping("/")
	public ResponseEntity<Order> save(@RequestBody OrderDTO orderDto) {
		Order order = new Order();
		order.setOrdDate(orderDto.getOrdDate());
		order.setCustName(orderDto.getCustName());
		return new ResponseEntity<Order>(orderService.save(order, orderDto.getItemList()), HttpStatus.OK);		
	}

}
