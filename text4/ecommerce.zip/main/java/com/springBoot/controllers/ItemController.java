package com.springBoot.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springBoot.Entities.Item;
import com.springBoot.dtos.ItemDTO;
import com.springBoot.exceptions.IllegalAgrumentException;
import com.springBoot.services.ItemService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/item")
public class ItemController {

	@Autowired
	ItemService itemService;

	@GetMapping("/")
	public ResponseEntity<List<Item>> getItems() {

		return new ResponseEntity<>(itemService.findAll(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Item> findByid(@PathVariable Long id) {
		if (id <= 0)
			throw new IllegalAgrumentException("id can't be negative");
		return new ResponseEntity<>(itemService.findById(id), HttpStatus.FOUND);
	}

	@PostMapping("/add")
	public Item save(@RequestBody ItemDTO itemDto) {
		System.out.println("in Add");
		return itemService.save(itemDto);
	}

	@PutMapping("/add/{id}")
	public ResponseEntity<Item> update(@PathVariable Long id, @RequestBody Item item) {
		if (id <= 0)
			throw new IllegalAgrumentException("id can't be negative");
		return new ResponseEntity<Item>(itemService.update(item, id), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteById(@PathVariable Long id) {
		if (id <= 0)
			throw new IllegalAgrumentException("id can't be negative");
		itemService.delete(id);
		return new ResponseEntity<String>("deleted successfully", HttpStatus.OK);
	}

}
