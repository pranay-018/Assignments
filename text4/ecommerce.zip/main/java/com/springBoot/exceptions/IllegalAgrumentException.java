package com.springBoot.exceptions;

public class IllegalAgrumentException extends RuntimeException {
	public IllegalAgrumentException(String msg) {
		super(msg);
	}
}
