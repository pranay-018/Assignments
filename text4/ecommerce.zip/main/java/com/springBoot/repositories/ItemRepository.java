package com.springBoot.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springBoot.Entities.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

}
