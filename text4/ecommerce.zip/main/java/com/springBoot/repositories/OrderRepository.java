package com.springBoot.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springBoot.Entities.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

}
