package com.springBoot.dtos;

import java.time.LocalDate;
import java.util.List;

import com.springBoot.Entities.Item;

public class OrderDTO {
	private LocalDate ordDate;
	private String custName;
	private List<Long> itemList;
	public OrderDTO() {
		super();
	}
	public OrderDTO(LocalDate ordDate, String custName, List<Long> itemList) {
		super();
		this.ordDate = ordDate;
		this.custName = custName;
		this.itemList = itemList;
	}
	public LocalDate getOrdDate() {
		return ordDate;
	}
	public void setOrdDate(LocalDate ordDate) {
		this.ordDate = ordDate;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public List<Long> getItemList() {
		return itemList;
	}
	public void setItemList(List<Long> itemList) {
		this.itemList = itemList;
	}
}
