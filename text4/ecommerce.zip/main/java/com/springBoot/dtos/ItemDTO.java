package com.springBoot.dtos;

public class ItemDTO {
	private String itemName;
	private Double itemCost;
	public ItemDTO() {
		super();
	}
	public ItemDTO( String itemName, Double itemCost) {
		super();
		this.itemName = itemName;
		this.itemCost = itemCost;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getItemCost() {
		return itemCost;
	}
	public void setItemCost(Double itemCost) {
		this.itemCost = itemCost;
	}
	@Override
	public String toString() {
		return "ItemDTO [itemName=" + itemName + ", itemCost=" + itemCost + "]";
	}
}
