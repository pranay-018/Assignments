package com.springBoot.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springBoot.Entities.Employee;
import com.springBoot.repositories.EmployeeRepo;

@Service
public class EmpService {
//	private static final Logger logger = LoggerFactory.getLogger(EmpService.class);
	@Autowired
	EmployeeRepo emprepo;

	public List<Employee> findAll() {
//		logger.info("fetching all employess");
		return emprepo.findAll();
	}

	public Employee findById(Long id) {
//		logger.info("fetching emp by ID");
		return emprepo.findById(id).get();
	}

	public Employee save(Employee e) {
//		logger.info("saving emp");
		emprepo.save(e);
		return e;
	}
	public List<Employee> findBysalaryAndName(Double salary,String name){
		return emprepo.findEmployeesBySalaryAndNameStartWithS(salary, name);
	}
}
