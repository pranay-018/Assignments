package com.springBoot.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.springBoot.Entities.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Long> {
	Employee findByname(String name);

	List<Employee> findBySalary(Double salaray);

	@Query(value =  "select * from employee_table where salary = :salary and name like concat(:name,'%')", nativeQuery = true)
	List<Employee> findEmployeesBySalaryAndNameStartWithS(@Param("salary") Double salary, @Param("name") String name);
}
