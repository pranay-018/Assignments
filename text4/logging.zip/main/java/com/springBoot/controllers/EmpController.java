package com.springBoot.controllers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springBoot.Entities.Employee;
import com.springBoot.services.EmpService;

@RestController
@RequestMapping("/emp")
public class EmpController {
	private static final Logger logger = LoggerFactory.getLogger(EmpController.class);
	@Autowired
	EmpService empServ;

	@GetMapping("/{id}")
	public Employee findById(@PathVariable Long id) {
		logger.info("request to find by Id  API");
		return empServ.findById(id);
	}

	@GetMapping("/")
	public List<Employee> findAll() {
		logger.info(" request to findall API");
		return empServ.findAll();
	}

	@PostMapping("/add")
	public Employee save(@RequestBody Employee e) {
		logger.info("request to save  API");
		return empServ.save(e);
	}

	@GetMapping("/search")
	public ResponseEntity<List<Employee>> getEmployeesBySalaryAndName(@RequestParam Double salary,
			@RequestParam String name) {

		List<Employee> employees = empServ.findBysalaryAndName(salary, name);

		return ResponseEntity.ok(employees);
	}
}
