package com.springboot.entities;

import org.hibernate.validator.constraints.UniqueElements;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.RequiredMode;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "user_table")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long userId;
	@Size(min = 3, message = "username must be min length of 3 chars")
	@NotBlank(message = "username is mandatory")
	@Schema(description = "username", example = "raj", requiredMode = RequiredMode.REQUIRED)
	private String userName;
	@NotBlank(message = "message not be blank")
	@Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$", message = "Password must contain at least one digit, one lowercase, one uppercase, and one special character")
	@Schema(description = "password", example = "pranay@18", requiredMode = RequiredMode.REQUIRED)
	private String password;
	@Pattern(regexp = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}", message = " enter valid email ")
	@Schema(description = "email", example = "pranay018@gmail.com", requiredMode = RequiredMode.REQUIRED)
	private String email;
	@Pattern(regexp = "^(?:(?:\\\\+|0{0,2})91)?[6-9]\\\\d{9}$\r\n", message = "must be 10 number and start from 6,7,8 and 9")
	@Schema(description = "mobile number", example = "9874563218")
	private String mobile;

	public User() {
		super();
	}

	public User(String userName, String password, String email, String mobile) {
		super();
		this.userName = userName;
		this.password = password;
		this.email = email;
		this.mobile = mobile;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", password=" + password + ", email=" + email
				+ ", mobile=" + mobile + "]";
	}
}
