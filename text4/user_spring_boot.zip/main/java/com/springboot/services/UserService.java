package com.springboot.services;

import java.util.List;
import com.springboot.entities.User;

public interface UserService {

    User saveUser(User user);

    User updateUser(Long id, User user);

    User getUserById(Long id);

    List<User> getAllUsers();

    void deleteUser(Long id);
}
