package com.springboot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

@Configuration
public class SwaggerConfig {
	@Bean
	public OpenAPI openApi() {
		return new OpenAPI()
				.info(new Info().title("USER MANAGEMENT APPLICATION")
						.description("swagger config demo using springboot user app")
						.version("1.0")
						.contact(new Contact()
								.name("API Team")
								.email("pranay@gmail.com")
								.url("com.springboot.userAPP"))
						.license(new License().name("apache 2.0")
								.url("http://www.apache.org./licenses/LICENCES-2.0")));
	}
}
