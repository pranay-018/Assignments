package com.springboot.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.entities.User;

@Repository
public interface UserRepo extends JpaRepository<User, Long> {

}
